#!/usr/bin/env python

#

##########################################################################

#									 #

#			 ** YouTube URL Lister **			 #

#									 #

#   Written by: 	Josh.5 (jsunnex@gmail.com)			 #

#   Date:		12 July, 2015					 #

#									 #

#   Credits:								 #

#	   - bromix (https://github.com/bromix/)			 #

#	   - sphere (https://github.com/dersphere/)			 #

#									 #

#   License: GPL (http://www.gnu.org/licenses/gpl-3.0.html)		 #

#									 #

##########################################################################



import xbmc, xbmcaddon, xbmcgui, xbmcplugin



## Plugin Info ##

ID		 = 'plugin.video.arnuboxhelp'

ADDON		 = xbmcaddon.Addon( ID )

ADDON_ID	 = ADDON.getAddonInfo('id')

ADDON_NAME	 = ADDON.getAddonInfo('name')

ADDON_ICON	 = ADDON.getAddonInfo('icon')

ADDON_VERSION	 = ADDON.getAddonInfo('version')

ADDON_DATA	 = xbmc.translatePath( "special://profile/addon_data/%s/" % ID )

ADDON_DIR	 = ADDON.getAddonInfo( "path" )

ICON_DIR	 = ADDON.getAddonInfo( "path" )+'/icons/'







playlists = [



################################ CONFIGURE PLAYLISTS ################################

##

## This contains the details of the youtube playlists that we will have.

## If you want to add a second playlist, uncomment the following and add the details.

## For more playlists, copy and paste again and again etc.

##

#####################################################################################

  {

    'name' : 'JarvisBox Video Guides >>>',

    'icon' : ADDON_ICON,	# <-- Icon from addon

    'playlist_id' : 'PL4DC51B406337ABB8',

  }

  #,

  #{

  #  'name' : 'ARNU Pure Linux Guide2 >>>',

  #  'icon' : ICON_DIR+'nextpage.png',	# <-- Icon from addon's 'icon' folder

  #  'playlist_id' : '-qp7reqCcay7v',

  #}

  #,

  #{

  #  'name' : 'ARNU Pure Linux Guide3 >>>',

  #  'icon' : 'DefaultVideo.png',	# <-- Icon from current skin

  #  'playlist_id' : '-qp7reqCcay7v',

  #}





]



for p in playlists:

  playback_url = 'plugin://plugin.video.youtube/playlist/'+p['playlist_id']+'/'

  item = xbmcgui.ListItem(p['name'], iconImage=p['icon'], path=playback_url)

  xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=playback_url, listitem=item, isFolder=True)



xbmcplugin.endOfDirectory(int(sys.argv[1]))


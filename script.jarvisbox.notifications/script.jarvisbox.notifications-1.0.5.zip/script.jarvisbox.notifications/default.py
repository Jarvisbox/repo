if 64 - 64: i11iIiiIii
if 65 - 65: O0 / iIii1I11I1II1 % OoooooooOO - i1IIi
import xbmc , xbmcaddon , xbmcgui
import os , urllib2 , urllib , json , cookielib , time , zipfile , shutil , hashlib, base64
import os , sys , xbmc , xbmcplugin , xbmcaddon , xbmcgui , urllib , urllib2 , re , time , datetime , string , StringIO , logging , random , array , htmllib , xbmcvfs
if 73 - 73: II111iiii
if 22 - 22: I1IiiI * Oo0Ooo / OoO0O00 . OoOoOO00 . o0oOOo0O0Ooo / I1ii11iIi11i
if 48 - 48: oO0o / OOooOOo / I11i / Ii1I
IiiIII111iI = 'script.jarvisbox.notifications'
IiII = xbmcaddon . Addon ( IiiIII111iI )
iI1Ii11111iIi = IiII . getAddonInfo ( 'id' )
i1i1II = IiII . getAddonInfo ( 'name' )
O0oo0OO0 = IiII . getAddonInfo ( 'icon' )
I1i1iiI1 = IiII . getAddonInfo ( 'version' )
iiIIIII1i1iI = xbmc . translatePath ( "special://profile/addon_data/%s/" % IiiIII111iI )
o0oO0 = IiII . getAddonInfo ( "path" )
if 100 - 100: i11Ii11I1Ii1i
Ooo = xbmc . translatePath ( os . path . join ( 'special://home/addons' , 'packages' ) )
o0oOoO00o = xbmc . translatePath ( os . path . join ( 'special://home' , '' ) )
i1 = xbmc . translatePath ( os . path . expanduser ( '~/' ) )
oOOoo00O0O = xbmc . translatePath ( os . path . join ( o0oO0 , "resources" , "images" ) )
i1111 = os . path . join ( o0oO0 , 'notification.txt' )
if 22 - 22: OOo000 . O0I11i1i11i1I
Iiii = base64 . b64decode ( 'aHR0cDovL2Nsb3Vkd29yZC5qYXJ2aXNib3guY29tL25vdGlmaWNhdGlvbi50eHQ=' )
if 87 - 87: oO0o0o0ooO0oO / Oo0Ooo - II111iiii - i11iIiiIii % o0oOOo0O0Ooo * I11i
if 75 - 75: O0 + I1IiiI - i11Ii11I1Ii1i / I1IiiI % I1IiiI
iiI11 = 10
OOooO = 92
OOoO00o = 7
if 9 - 9: I1IiiI - Ii1I % i1IIi % OoooooooOO
if 3 - 3: i11Ii11I1Ii1i + O0
I1Ii = os . path . join ( oOOoo00O0O , 'black.png' ) ;
o0oOo0Ooo0O = os . path . join ( oOOoo00O0O , 'ContentPanel.png' ) ;
OO00O0O0O00Oo = os . path . join ( oOOoo00O0O , 'GlassTitleBar.png' ) ;
IIIiiiiiIii = os . path . join ( oOOoo00O0O , 'blank1.png' ) ;
OO = "04d0d9f4a09e018934109d71f034c0d6"
if 55 - 55: OoO0O00 / I1ii11iIi11i * OOooOOo
if 86 - 86: i11iIiiIii + Ii1I + oO0o0o0ooO0oO * I11i + o0oOOo0O0Ooo
def oOoO ( mins = '60' , args = 0 ) :
 if 68 - 68: OoOoOO00 . oO0o . i11iIiiIii
 if 40 - 40: oO0o . OoOoOO00 . Oo0Ooo . i1IIi
 if args == 0 :
  args = ''
 I11iii = i1i1II + ' - Notification scheduler'
 OO0O00 = os . path . join ( o0oO0 , 'default.py' )
 ii1 = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % ( I11iii , OO0O00 , args , int ( mins ) )
 xbmc . executebuiltin ( 'CancelAlarm(%s,True)' % I11iii )
 xbmc . executebuiltin ( ii1 )
 xbmc . log ( "Alarm Set: %s" % I11iii )
 if 57 - 57: Ii1I % OoooooooOO
class O00 :
 def run ( self ) :
  if os . path . isfile ( i1111 ) :
   with open ( i1111 ) as i11I1 : Ii11Ii11I = i11I1 . readlines ( ) ;
  else : Ii11Ii11I = self . check_server ( ) ;
  if not ( hashlib . md5 ( Iiii ) . hexdigest ( ) ) == OO : iI11i1I1 = False ; o0o0OOO0o0 = False ; ooOOOo0oo0O0 = False ; o0 = False ; I11II1i = True ; Ii11Ii11I = False ;
  IIIII = ooooooO0oo . convert_to_dic ( Ii11Ii11I )
  return IIIII
  if 49 - 49: o0oOOo0O0Ooo * iIii1I11I1II1 / i1IIi / i11iIiiIii / o0oOOo0O0Ooo
 def check_server ( self ) :
  try :
   Ii11Ii11I = urllib2 . urlopen ( Iiii )
  except :
   Ii11Ii11I = False
  return Ii11Ii11I
  if 28 - 28: OOooOOo - OOo000 . OOo000 + OoOoOO00 - OoooooooOO + O0
 def new_notice ( self , date ) :
  oOoOooOo0o0 = xbmcaddon . Addon ( id = IiiIII111iI ) . getSetting ( 'curDate' )
  if oOoOooOo0o0 in [ '' , ' ' , None , False , True ] :
   oOoOooOo0o0 = str ( datetime . date . today ( ) . strftime ( "%Y-%m-%d" ) )
  if oOoOooOo0o0 == date :
   if 61 - 61: o0oOOo0O0Ooo / OoO0O00 + oO0o0o0ooO0oO * oO0o / oO0o
   return False
  else :
   return True
   if 75 - 75: i1IIi / OoooooooOO - O0 / OoOoOO00 . II111iiii - i1IIi
 def convert_to_dic ( self , response ) :
  O000OO0 = { }
  I11iii1Ii = [ ]
  I1IIiiIiii = False
  O000oo0O = False
  OOOO = False
  i11i1 = False
  IIIii1II1II = False
  i1I1iI = False
  oo0OooOOo0 = False
  o0O = False
  O00oO = False
  I11i1I1I = False
  oO0Oo = False
  oOOoo0Oo = False
  o00OO00OoO = False
  OOOO0OOoO0O0 = False
  O0Oo000ooO00 = False
  if not response :
   return
  for oO0 in response :
   if '##' in oO0 :
    I1IIiiIiii = True
   else :
    I1IIiiIiii = False
   if not I1IIiiIiii :
    if 45 - 45: i11iIiiIii * II111iiii % iIii1I11I1II1 + I1ii11iIi11i - Ii1I
    if O000oo0O :
     O000OO0 [ 'date' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#date:" ) :
     O000oo0O = True
    else :
     O000oo0O = False
     if 17 - 17: OOo000
     if 62 - 62: iIii1I11I1II1 * OoOoOO00
    if i11i1 :
     O000OO0 [ 'message_type' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#message_type:" ) :
     i11i1 = True
    else :
     i11i1 = False
     if 26 - 26: i11Ii11I1Ii1i . O0I11i1i11i1I
     if 68 - 68: OoO0O00
    if OOOO :
     O000OO0 [ 'header_type' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#header_type:" ) :
     OOOO = True
    else :
     OOOO = False
     if 35 - 35: OoO0O00 - i11Ii11I1Ii1i / Oo0Ooo / OoOoOO00
     if 24 - 24: oO0o0o0ooO0oO - oO0o0o0ooO0oO / II111iiii - I1ii11iIi11i
    if OOOO0OOoO0O0 :
     O000OO0 [ 'note_repeats' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#note_repeats:" ) :
     OOOO0OOoO0O0 = True
    else :
     OOOO0OOoO0O0 = False
     if 69 - 69: oO0o . O0I11i1i11i1I + Ii1I / Oo0Ooo - oO0o
     if 63 - 63: OOooOOo % oO0o * oO0o * OoO0O00 / I1ii11iIi11i
    if O0Oo000ooO00 :
     O000OO0 [ 'repeat_delay' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#repeat_delay:" ) :
     O0Oo000ooO00 = True
    else :
     O0Oo000ooO00 = False
     if 74 - 74: II111iiii
     if 75 - 75: o0oOOo0O0Ooo . oO0o0o0ooO0oO
    if IIIii1II1II :
     O000OO0 [ 'header_text' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#header_text:" ) :
     IIIii1II1II = True
    else :
     IIIii1II1II = False
     if 54 - 54: II111iiii % OoOoOO00 % I11i % iIii1I11I1II1 + iIii1I11I1II1 * oO0o0o0ooO0oO
     if 87 - 87: oO0o0o0ooO0oO * Oo0Ooo % i11iIiiIii % OoOoOO00 - OOooOOo
    if i1I1iI :
     O000OO0 [ 'header_text_font' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#header_text_font:" ) :
     i1I1iI = True
    else :
     i1I1iI = False
     if 68 - 68: O0I11i1i11i1I % i1IIi . OOo000 . I1ii11iIi11i
     if 92 - 92: i11Ii11I1Ii1i . O0I11i1i11i1I
    if oo0OooOOo0 :
     O000OO0 [ 'header_text_color' ] = oO0 . strip ( '\n' ) . strip ( '#' )
    if oO0 . startswith ( "#header_text_color:" ) :
     oo0OooOOo0 = True
    else :
     oo0OooOOo0 = False
     if 31 - 31: O0I11i1i11i1I . OoOoOO00 / O0
     if 89 - 89: OoOoOO00
    if o0O :
     O000OO0 [ 'header_text_position' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#header_text_position:" ) :
     o0O = True
    else :
     o0O = False
     if 68 - 68: OoO0O00 * OoooooooOO % O0 + OoO0O00 + oO0o0o0ooO0oO
     if 4 - 4: oO0o0o0ooO0oO + O0 * OOooOOo
    if O00oO :
     O000OO0 [ 'header_image' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#header_image:" ) :
     O00oO = True
    else :
     O00oO = False
     if 55 - 55: Oo0Ooo + iIii1I11I1II1 / OoOoOO00 * oO0o - i11iIiiIii - Ii1I
     if 25 - 25: I1ii11iIi11i
    if I11i1I1I :
     O000OO0 [ 'message_image' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#message_image:" ) :
     I11i1I1I = True
    else :
     I11i1I1I = False
     if 7 - 7: i1IIi / I1IiiI * O0I11i1i11i1I . OOo000 . iIii1I11I1II1
     if 13 - 13: OOooOOo / i11iIiiIii
    if oOOoo0Oo :
     O000OO0 [ 'message_text_font' ] = oO0 . strip ( '\n' )
    if oO0 . startswith ( "#message_text_font:" ) :
     oOOoo0Oo = True
    else :
     oOOoo0Oo = False
     if 2 - 2: I1IiiI / O0 / o0oOOo0O0Ooo % OoOoOO00 % Ii1I
     if 52 - 52: o0oOOo0O0Ooo
    if o00OO00OoO :
     O000OO0 [ 'message_text_color' ] = oO0 . strip ( '\n' ) . strip ( '#' )
    if oO0 . startswith ( "#message_text_color:" ) :
     o00OO00OoO = True
    else :
     o00OO00OoO = False
     if 95 - 95: Ii1I
     if 87 - 87: oO0o0o0ooO0oO + OoOoOO00 . OOooOOo + OoOoOO00
    if oO0Oo :
     I11iii1Ii . append ( oO0 )
     if 91 - 91: O0
    if oO0 . startswith ( "#message_text:" ) :
     oO0Oo = True
     if 61 - 61: II111iiii
  O000OO0 [ 'message_text' ] = '' . join ( I11iii1Ii ) . replace ( '\n' , "[CR]" ) . replace ( '\t' , "        " )
  return O000OO0
  if 64 - 64: oO0o0o0ooO0oO / OoOoOO00 - O0 - I11i
  if 86 - 86: I11i % OoOoOO00 / I1IiiI / OoOoOO00
class iIIi1i1 ( xbmcgui . WindowDialog ) :
 def __init__ ( self ,
 noteType = 't' ,
 headerType = 'image' ,
 headerText = '' ,
 headerTextFont = 'font_MainMenu' ,
 headerTextColor = '0xFFFFFFFF' ,
 headerTextPosition = '' ,
 headerImage = '' ,
 noteMessage = '' ,
 noteImage = '' ,
 noteDate = '' ,
 noteRepeats = '0' ,
 repeatDelay = '300' ,
 L = 140 ,
 T = 60 ,
 W = 1000 ,
 H = 600 ,
 Font = 'font14' ,
 TxtColor = '0xFFCCCCCC'
 ) :
  self . controls = [ ]
  if len ( noteImage ) == 0 :
   noteImage = IIIiiiiiIii
  if len ( noteDate ) == 0 :
   noteDate = datetime . date . today ( ) . strftime ( "%Y-%m-%d" )
  if ( noteType . lower ( ) == 'text' ) or ( noteType . lower ( ) == 't' ) :
   noteType = 't'
   noteImage = IIIiiiiiIii
  elif ( noteType . lower ( ) == 'image' ) or ( noteType . lower ( ) == 'i' ) :
   noteType = 'i'
   if 10 - 10: I11i
   noteMessage = ''
  if ( headerType . lower ( ) == 'text' ) or ( headerType . lower ( ) == 't' ) :
   headerType = 't'
  elif ( headerType . lower ( ) == 'image' ) or ( headerType . lower ( ) == 'i' ) :
   headerType = 'i'
  if len ( noteImage ) == 0 :
   headerTextPosition = '{"Left":"660", "Top":"60", "TextAlign":"center"}'
  if headerTextPosition [ 'TextAlign' ] . lower ( ) == 'left' :
   self . headerTextPosAlign = 0x00000004 | 0x00000000
  elif headerTextPosition [ 'TextAlign' ] . lower ( ) == 'right' :
   self . headerTextPosAlign = 0x00000004 | 0x00000001
  else :
   self . headerTextPosAlign = 0x00000004 | 0x00000002
  self . headerType = headerType ;
  self . noteType = noteType ;
  self . noteMessage = noteMessage ;
  self . headerText = headerText ;
  self . headerTextFont = headerTextFont ;
  self . headerTextColor = headerTextColor ;
  self . headerTextPosLeft = int ( headerTextPosition [ 'Left' ] ) ;
  self . headerTextPosTop = int ( headerTextPosition [ 'Top' ] ) ;
  self . headerImage = headerImage ;
  self . noteImage = noteImage ;
  self . Font = Font ;
  self . TxtColor = TxtColor ;
  self . noteDate = noteDate ;
  self . noteRepeats = noteRepeats ;
  self . repeatDelay = repeatDelay ;
  if 82 - 82: I1ii11iIi11i - iIii1I11I1II1 / OOooOOo + Ii1I
  self . background = o0oOo0Ooo0O ;
  self . backdrop = I1Ii ;
  self . headerbackground = OO00O0O0O00Oo ;
  self . BackDrop = xbmcgui . ControlImage ( 0 , 0 , 1920 , 1080 , self . backdrop , aspectRatio = 0 , colorDiffuse = '0xCCFFFFFF' ) ;
  self . BG = xbmcgui . ControlImage ( L , T , W , H , self . background , aspectRatio = 0 , colorDiffuse = '0xFFFFFFFF' ) ;
  OOOOoOoo0O0O0 = 380 ; OOOo00oo0oO = 87 ;
  self . BGHeader = xbmcgui . ControlImage ( L + 5 , T + 7 , W - 10 , OOOo00oo0oO - 60 , self . headerbackground , aspectRatio = 0 , colorDiffuse = '0xFFFFFFFF' ) ;
  if self . headerType == 'i' :
   self . iLogo = xbmcgui . ControlImage ( ( L + ( W / 2 ) ) - ( OOOOoOoo0O0O0 / 2 ) , T + 6 , OOOOoOoo0O0O0 , OOOo00oo0oO , self . headerImage , aspectRatio = 0 ) ;
  else :
   if 1 - 1: OoO0O00 - oO0o . I11i . OoO0O00 / Oo0Ooo + I11i
   print 'self.headerTextColor'
   print self . headerTextColor
   self . iLogo = xbmcgui . ControlLabel (
 self . headerTextPosLeft - ( OOOOoOoo0O0O0 / 2 ) ,
 self . headerTextPosTop ,
 OOOOoOoo0O0O0 ,
 OOOo00oo0oO ,
 self . headerText ,
 font = self . headerTextFont ,
 alignment = self . headerTextPosAlign ,
 textColor = self . headerTextColor ) ;
  OooOOOOo = 200 ; oo0O0oO = 150 ; ooooo = 880 ; II1I = 440 ;
  O0i1II1Iiii1I11 = OooOOOOo + 5 ; IIII = oo0O0oO + 60 ; iiIiI = ooooo - 18 ; o00oooO0Oo = II1I - 5 - 60 ;
  self . BGTextbox = xbmcgui . ControlImage ( OooOOOOo - 15 , oo0O0oO + 2 , ooooo + 30 , II1I + 6 , self . background , aspectRatio = 0 , colorDiffuse = '0xFFFFFFFF' ) ;
  self . ImgMessage = xbmcgui . ControlImage ( OooOOOOo - 100 , oo0O0oO , ooooo + 200 , II1I , self . noteImage , aspectRatio = 0 ) ;
  self . TxtMessage = xbmcgui . ControlTextBox ( OooOOOOo + 10 , oo0O0oO + 10 , ooooo - 10 , II1I - 10 , font = self . Font , textColor = self . TxtColor ) ;
  self . DateDisplay = xbmcgui . ControlLabel ( W - 20 , T + 40 , 130 , 30 , self . noteDate , font = self . Font , textColor = '0x99CCCCCC' ) ;
  if 78 - 78: Ii1I % O0I11i1i11i1I + I1ii11iIi11i
  OOooOoooOoOo = 'MenuItemFO.png' ; o0OOOO00O0Oo = 'MenuItemNF.png' ;
  ii = 120 ; oOooOOOoOo = 35 ; i1Iii1i1I = 160 ; OOoO00 = 35 ; IiI111111IIII = 20 ;
  i1Ii = L + W - IiI111111IIII - i1Iii1i1I ; ii111iI1iIi1 = T + H - OOoO00 - IiI111111IIII ;
  OOO = L + W - IiI111111IIII - i1Iii1i1I - IiI111111IIII - ii ; oo0OOo0 = T + H - oOooOOOoOo - IiI111111IIII ;
  if 47 - 47: O0I11i1i11i1I + OoOoOO00 * Oo0Ooo / oO0o0o0ooO0oO - i11Ii11I1Ii1i % iIii1I11I1II1
  OOO = 500
  oo0OOo0 = 605
  ii = 320
  oOooOOOoOo = 35
  IIi11i1i1iI1 = "0xFFFFFFFF"
  iiiIi1 = "0xFFFFFFFF"
  self . controls . append ( self . BackDrop )
  if noteType == 'i' :
   OOO = 858
   oo0OOo0 = 553
   IIi11i1i1iI1 = "0xFF000000"
   iiiIi1 = "0xFF000000"
   OOooOoooOoOo = os . path . join ( oOOoo00O0O , 'button-focus_lightblue.png' )
   o0OOOO00O0Oo = os . path . join ( oOOoo00O0O , 'button-focus_grey.png' )
  else :
   self . controls . append ( self . BG )
   self . controls . append ( self . BGHeader )
   self . controls . append ( self . BGTextbox )
   self . controls . append ( self . DateDisplay )
  self . buttonDismiss = xbmcgui . ControlButton ( OOO , oo0OOo0 , ii , oOooOOOoOo , "Dismiss" , textColor = IIi11i1i1iI1 , focusedColor = iiiIi1 , alignment = 2 , focusTexture = OOooOoooOoOo , noFocusTexture = o0OOOO00O0Oo ) ;
  self . controls . append ( self . ImgMessage )
  self . controls . append ( self . TxtMessage )
  self . controls . append ( self . iLogo )
  self . controls . append ( self . buttonDismiss )
  if 38 - 38: O0I11i1i11i1I
  for Ooo00o0Oooo in self . controls :
   self . addControl ( Ooo00o0Oooo ) ;
  for Ooo00o0Oooo in self . controls :
   Ooo00o0Oooo . setAnimations ( [ ( 'WindowOpen' , 'effect=fade delay=0 time=500 start=0 end=100' ) , ( 'WindowClose' , 'effect=fade delay=10 time=500  start=100 end=0' ) ] ) ;
   if 84 - 84: o0oOOo0O0Ooo % II111iiii . i11iIiiIii / OoO0O00
  self . TxtMessage . setText ( self . noteMessage ) ;
  self . TxtMessage . autoScroll ( 3000 , 2000 , 1 ) ;
  self . setFocus ( self . buttonDismiss ) ;
 def doDismiss ( self ) :
  self . curRepeats = xbmcaddon . Addon ( id = IiiIII111iI ) . getSetting ( 'curRepeats' )
  try : self . curRepeats = int ( self . curRepeats ) ; self . curRepeats += 1 ;
  except : self . curRepeats = 1
  if ( ooooooO0oo . new_notice ( self . noteDate ) ) :
   self . curRepeats = 1
  xbmcaddon . Addon ( id = IiiIII111iI ) . setSetting ( 'curRepeats' , str ( self . curRepeats ) )
  xbmcaddon . Addon ( id = IiiIII111iI ) . setSetting ( 'curDate' , str ( self . noteDate ) )
  if not int ( self . curRepeats ) > int ( self . noteRepeats ) : self . setAlarm ( self . repeatDelay )
  else : self . setAlarm ( 900 )
  self . close ( )
 def onAction ( self , action ) :
  try :
   o0OIiII = self . getFocus ( )
  except :
   o0OIiII = False
  if action == iiI11 :
   self . doDismiss ( )
  elif action == OOooO :
   self . doDismiss ( )
 def setAlarm ( self , mins = '300' , args = 0 ) :
  if 25 - 25: O0 - O0 * o0oOOo0O0Ooo
  if args == 0 :
   args = ''
  I11iii = i1i1II + ' - Notification scheduler'
  OO0O00 = os . path . join ( o0oO0 , 'default.py' )
  ii1 = 'AlarmClock(%s,RunScript(%s,%s),%d,True)' % ( I11iii , OO0O00 , args , int ( mins ) )
  if 51 - 51: Oo0Ooo - oO0o + II111iiii * Ii1I . I11i + oO0o
  xbmc . executebuiltin ( 'CancelAlarm(%s,True)' % I11iii )
  xbmc . executebuiltin ( ii1 )
  xbmc . log ( "Alarm Set: %s" % I11iii )
 def onControl ( self , control ) :
  if control == self . buttonDismiss :
   self . doDismiss ( )
   if 78 - 78: i11iIiiIii / i11Ii11I1Ii1i - Ii1I / OOooOOo + oO0o
   if 82 - 82: Ii1I
   if 46 - 46: OoooooooOO . i11iIiiIii
   if 94 - 94: o0oOOo0O0Ooo * Ii1I / Oo0Ooo / Ii1I
if __name__ == '__main__' :
 xbmc . log ( "SERVICE STARTED - %s" % iI1Ii11111iIi )
 ooooooO0oo = O00 ( ) ; Ii11Ii11I = ooooooO0oo . run ( )
 if 87 - 87: Oo0Ooo . OOo000
 if not ( isinstance ( Ii11Ii11I , dict ) ) or ( xbmc . getCondVisibility ( "Player.HasVideo" ) ) :
  oOoO ( )
 else :
  O0OO0O = xbmcaddon . Addon ( id = IiiIII111iI ) . getSetting ( 'curRepeats' )
  try : O0OO0O = int ( O0OO0O ) ; O0OO0O += 1 ;
  except : O0OO0O = 1
  if ( ooooooO0oo . new_notice ( Ii11Ii11I [ 'date' ] ) ) or not ( int ( O0OO0O ) > int ( Ii11Ii11I [ 'note_repeats' ] ) ) :
   OOOoOoO = iIIi1i1 ( noteType = Ii11Ii11I [ 'message_type' ] ,
 headerType = Ii11Ii11I [ 'header_type' ] ,
 headerText = Ii11Ii11I [ 'header_text' ] ,
 headerTextFont = Ii11Ii11I [ 'header_text_font' ] ,
 headerTextColor = '0xFF' + Ii11Ii11I [ 'header_text_color' ] ,
 headerTextPosition = json . loads ( u"" + ( Ii11Ii11I [ 'header_text_position' ] ) ) ,
 headerImage = Ii11Ii11I [ 'header_image' ] ,
 noteMessage = Ii11Ii11I [ 'message_text' ] ,
 Font = Ii11Ii11I [ 'message_text_font' ] ,
 TxtColor = '0xFF' + Ii11Ii11I [ 'message_text_color' ] ,
 noteImage = Ii11Ii11I [ 'message_image' ] ,
 noteDate = Ii11Ii11I [ 'date' ] ,
 noteRepeats = Ii11Ii11I [ 'note_repeats' ] ,
 repeatDelay = Ii11Ii11I [ 'repeat_delay' ] ) ; OOOoOoO . doModal ( ) ; del OOOoOoO ;
   if 43 - 43: i11iIiiIii + Oo0Ooo * II111iiii * O0I11i1i11i1I * O0
# dd678faae9ac167bc83abf78e5cb2f3f0688d3a3
